// Excercise01: This file contains the 'main' function. Program execution begins and ends there.
// Write a template class that implements a single - linked list.
// Write two methods of this class, both of which will reverse the order of the elements in the list.
// One function should use a recursive approach; the second function should use an iterative approach.
// For both functions, do not create a new list items; must instead re - use existing list items.

/*
 *   Single Linked List Template Class Implementation
 *
 *   Methods:
 *      - add_node: Adds a node to the linked list.
 *      - print_linked_list: Displays the elements in the linked list.
 *      - reverse_using_iterative: Reverses the linked list iteratively.
 *      - reverse_using_recursion: Reverses the linked list recursively.
 *
 *   Demonstration:
 *      - LinkedList<int> with numbers 1-10.
 *      - LinkedList<char> with characters A-Z.
 *
 *   The reverse operation is performed on both lists using iterative and recursive approaches.
 *   
 *   Run Excercise01.exe, which display the output reverse operations on above mentioned lists.
 */

#include<iostream>
#include<memory>
using namespace std;

template<typename T>
class Node {
public:
    T data;
    Node* next;

    Node() : data(T()), next(nullptr) {}
    Node(T val) : data(val), next(nullptr) {}
};

/**
 * LinkedList Template Class with the following methods:
 *   - add_node: Adds a node to the linked list or assigns it as the head if the list is empty.
 *   - print_linked_list: Displays all the elements in the linked list.
 *   - reverse_using_iterative: Reverses the linked list using an iterative approach.
 *   - reverse_using_recursion: Reverses the linked list using a recursive approach.
 */

template<typename T>
class LinkedList {
private:

    Node<T>* head;


    // This is a helper function for reverse_using_recursion
    // which will do acutual reversal using recursion and 
    // return new head to reverse_using_recursion function.
    Node<T>* reverse_recursive_helper(Node<T>* curr) {
        if (curr == nullptr || curr->next == nullptr) {
            return curr;
        }

        Node<T>* new_head = reverse_recursive_helper(curr->next);
        curr->next->next = curr;
        curr->next = nullptr;
        return new_head;
    }

public:

    LinkedList() {
        head = nullptr;
    }

    void add_node(T val) {

        try
        {
            Node<T>* node = new Node<T>(val);

            if (head == nullptr) {
                head = node;
            }
            else {
                Node<T>* temp = head;
                while (temp->next != nullptr) {
                    temp = temp->next;
                }
                temp->next = node;
            }
        }
        catch (const std::bad_alloc& e) {
            cout << "Memory allocation failed while adding a new node: " << e.what() << endl;
            throw; 
        }
    }

    void print_linked_list() const {
        if (head == nullptr) {
            cout << "Empty Linked list, no elements to display" << endl;
            return;
        }

        Node<T>* temp = head;
        cout << "Elements in the Linked List: ";
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    void reverse_using_iterative() {
        if (head == nullptr) {
            return;
        }

        Node<T>* prev = nullptr;
        Node<T>* current = head;

        while (current != nullptr) {
            Node<T>* next_node = current->next;
            current->next = prev;
            prev = current;
            current = next_node;
        }
        head = prev;
        cout << "Linked List reversed using iterative approach" << endl;
    }

    void reverse_using_recursion() {
        if (head == nullptr) {
            return;
        }
        head = reverse_recursive_helper(head);
        cout << "Linked List reversed using recursion approach" << endl;
    }

    ~LinkedList()
    {
        Node<T>* current = head;
        while (current != nullptr) {
            Node<T>* next_node = current->next;
            delete current;
            current = next_node;
        }
        head = nullptr;
    }
};

int main()
{
    cout << "This is demo of LinkedList program" << endl;
    try
    {
        LinkedList<int>  list;

        list.print_linked_list();
        cout << endl;

        cout << "Adding 1 to 10 integers to LinkedList<int>" << endl;
        for (int i = 1; i <= 10; i++) {
            list.add_node(i);
        }
        list.print_linked_list();
        list.reverse_using_iterative();
        list.print_linked_list();
        list.reverse_using_recursion();
        list.print_linked_list();
        cout << endl;

        LinkedList<char>  charlist;

        cout << "Adding A to Z characters to LinkedList<char>" << endl;
        for (int i = 65; i <= 90; i++) {
            charlist.add_node(char(i));
        }

        charlist.print_linked_list();
        charlist.reverse_using_iterative();
        charlist.print_linked_list();
        charlist.reverse_using_recursion();
        charlist.print_linked_list();
        cout << endl;

    }
    catch (const exception& e) {
        cout << "Exception caught: " << e.what() << endl;
    }

    return 0;
}
