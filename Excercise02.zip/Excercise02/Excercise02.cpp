//  Excercise 02 : A double - square number is an integer X which can be expressed as the sum of two perfect squares.  
//  Input
//  Command line executable called DoubleSquare.exe which takes a single parameter N   
//  and returns the different ways N can be written as the sum of two squares.
//  For example,
//     DoubleSquare.exe 25
//           5 ^ 2 + 0 ^ 2
//           4 ^ 2 + 3 ^ 2
// 
//   After building this sln project, you will get DoubleSquare.exe, 
//   which needs to run with input argument.
//


#include<iostream>
#include<string>
#include<cmath>


using namespace std;

 /*
  * Function: print_perfect_squares
  * --------------------------------
  * This function prints all the unique pairs of integers (a, b) such that:
  *    n = a^2 + b^2 
  * 
  * The function iterates over possible values of 'a', calculates 'b', and checks
  * if 'b' is a perfect square. If the pair (a, b) is valid (i.e., a^2 + b^2 = n),
  * it is printed to the console. It ensures that each pair is only printed once,
  * by enforcing the condition that a <= b.
  *
  * Parameters:
  * - n: The integer for which we want to find pairs (a, b) such that n = a^2 + b^2.
  *
  * Steps:
  * 1. Calculate the integer square root of 'n', which is the maximum possible value of 'a'.
  * 2. Iterate over all possible values of 'a' from 0 to sqrt_n.
  * 3. For each 'a', calculate 'b' as sqrt(n - a^2).
  * 4. Check if 'b' is a valid integer (i.e., b is a perfect square).
  * 5. Ensure that only one instance of each pair is printed (by checking a <= b).
  * 
  */

void print_perfect_squares(int n) {
    bool ps_found = false;
    int sqrt_n = static_cast<int>(sqrt(n));

    for (int a = 0; a <= sqrt_n; a++) {
        double b = sqrt(n - a * a);

        // Check if 'b' is a perfect square and if 'a' <= 'b' to avoid duplicate pairs
        if (b == static_cast<int>(b) && a <= b) {
            cout << a << "^2+" << b << "^2" << endl;
            ps_found = true;
        }
    }

    if(!ps_found)
       cout <<  "No perfect squares found" << endl;
}


int main(int argc, char* argv[]) {
    int n;

    if (argc < 2) {
        cerr << "Please provide a number as a command-line argument." << endl;
        return 1;
    }

    try
    {
        n = stoi(argv[1]);

        if (n < 0) {
            throw runtime_error("Negative integer entered.");  
            return 1;
        }

    }
    catch (const invalid_argument& e) { // Catch invalid input other than the integer.
        cerr << "Invalid input: Please enter a valid integer. Exception at: " << e.what() << endl;
        return 1;
    }
    catch (const out_of_range& e) {  // Catch larger integer values exception
        cerr << "Input out of range: Please enter a smaller integer. Exception at: " << e.what() << endl;
        return 1;
    }
    catch (const runtime_error& e) {  // Catch negative number exception
        cerr << "Error: " << e.what() << endl;   
        return 1;
    }

    print_perfect_squares(n);

    return 0;
}