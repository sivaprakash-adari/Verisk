/*
*  Parallel Programming Exercise:
* 
*  Given an array of uchars, implement the multithreading application to determine the frequency of distinct values in the array. 
*  From the function prototype below, accessing result[0] would give the frequency of the value 0, result[1] would give the frequency of value 1, etc.  
*
*  Solution :
* 
*  This program splits the input data into smaller chunks, with each chunk
*  being processed by a separate thread. Each thread calculates the frequency
*  of characters within its assigned chunk and updates the shared result array.
*
*  The input string `uchars[]` is initialized with a sample value, and the
*  result array is printed for a commonly used character range.
*
*  Threads use mutexes to safely update the shared result array in a concurrent environment.
*
*/
#include<thread>
#include<iostream>
#include<cstring>
#include<iomanip>
#include<mutex>
#include<stdint.h>
#include<vector>

using namespace std;

typedef unsigned int uint;

mutex mtx;

// Global exception pointer to save exceptions occurred in thread
exception_ptr thread_exception = nullptr; 


// Function to calculate frequencies for a specific range of elements
void calculateFrequencies(unsigned char* inputData, int start, int end, uint* result) {
    try {
        uint temp_result[256] = { 0 };

        for (int i = start; i < end; i++) {
            temp_result[inputData[i]]++;
        }

        std::lock_guard<std::mutex> lock(mtx);
        for (int i = 0; i < 256; ++i) {
            result[i] += temp_result[i];
        }
    }
    catch (...) {  // Catch any exception
        lock_guard<mutex> lock(mtx);
        thread_exception = current_exception();  // Store the exception for later propagation
    } 
}


void CreateHistogram(unsigned char* inputData, int dataCount /* Length of inputData */, uint* result/*Output result*/) {

    try 
    {
       if (inputData == nullptr || result == nullptr) {
           throw invalid_argument("Input or result pointer is null");
       }

       if (dataCount <= 0) {
           throw invalid_argument("Data size must be greater than 0.");
       }

       const int numThreads = min(3, dataCount);  // This program uses 3 threads and it can be changed.

       std::fill_n(result, 256, 0);


       const int chunk_size = dataCount / numThreads;   
       vector<thread> threads;

       // Start threads to calculate frequencies for each chunk
       for (int i = 0; i < numThreads; i++) {
           int start = i * chunk_size;
           int end = min(start + chunk_size, dataCount);
           threads.emplace_back(calculateFrequencies, inputData, start, end, result);
       }

       // Wait for threads to finish
       for (auto& thread : threads) {
            thread.join();
       }

       // Check if any exception was thrown in the threads
       if (thread_exception) {
           std::rethrow_exception(thread_exception);  // Rethrow the exception in the main thread
       }
    }
    catch (const std::exception& e) {
          cerr << "Error in CreateHistogram: " << e.what() << endl;
          throw; // Rethrow the exception to be handled by the calling function
    }
}


int main()
{
    try
    {
        // since it is exercise program, stack memory is used.
        unsigned char uchars[] = "abcdefghijklmnopqrstuvwxyzabbbqAAAABB234499495%^&*V))!@#$:<>???123456789d";

        int len = sizeof(uchars) / sizeof(uchars[0]);

        uint result[256];  // Result array;

        CreateHistogram(uchars, len, result);

        cout << "Input string: " << uchars << endl;
        cout << endl;
        cout << "Frequency of each value " << endl;

        // Print frequency of each value
        for (int i = 40; i < 123; ++i) {
            if (i % 10 == 0)
                cout << endl;
            cout << setw(3) << i << ": " << result[i] << "  ";
        }
        cout << endl;

    } catch (const std::exception& e) {
        cerr << "Error: " << e.what() << endl;
        return 1; // Return non-zero exit code to indicate failure
    }

    return 0;

}